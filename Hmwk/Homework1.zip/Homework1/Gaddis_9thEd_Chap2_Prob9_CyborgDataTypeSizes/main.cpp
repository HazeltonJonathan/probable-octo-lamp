/* 
 * File:   main.cpp
 * Author: Jonathan Hazelton
 * Created on June 30, 2022, 11:17 AM
 * Purpose: Cyborg Data Type Sizes Problem
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
  
    
    
    //Initialize Variables

    
    
    //Map inputs to outputs -> The Process

    
    //Display Results
    cout<<"Size of Char bytes = "<<sizeof(char);
    cout<<" bytes. \n";
    cout<<"Size of Int bytes = "<<sizeof(int);
    cout<<" bytes. \n";
    cout<<"Size of Float bytes = "<<sizeof(float);
    cout<<" bytes. \n";
    cout<<"Size of Double bytes = "<<sizeof(double);
    cout<<" bytes. \n";
   
    
    //Exit Stage Right
    return 0;
}

